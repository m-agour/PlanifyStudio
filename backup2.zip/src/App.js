import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
// import ActivatePage from "./pages/activate/activate";
import Home from "./pages/home/home";
import LogIn from "./pages/login/login";
import SignUp from "./pages/signup/signup";
import MainPage from "./pages/mainpage/mainpage";
import Settings from "./pages/settings/settings";
import Archive from "./pages/archive/archive";
import Howitworks from "./pages/howitworks/howitworks";
import Upgrade from "./pages/upgrade/upgrade";
import SideBarData from "./components/sidebar/sidebardata";
import SideBar from "./components/sidebar/sidebar";
// import Footer from "./components/footer/footer";
import Header from "./components/header/header";
import Community from "./pages/community/community";
import { Fragment } from "react";
// import * as FaIcon from "react-icons/fa";
// import * as AiIcon from "react-icons/ai";
// import { logOut, isLoggedIn } from './services/helpers';
// import { useNavigate, Navigate } from "react-router-dom";
import { useState } from "react";
import { isLoggedIn } from "./services/helpers";
import Studio from "./pages/studio/studio";

function App() {
  // const navigate = useNavigate();

  return (
    // <Navigate to="/login" />

    // ) : (

    <Fragment>
      <BrowserRouter>
        <div>
          {isLoggedIn() && window.location.pathname !== "/studio" ? <SideBarData /> : null}
          {window.location.pathname !== "/studio" && <Header />}
        </div>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<LogIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/mainpage" element={<MainPage />} />
          <Route path="/archive" element={<Archive />} />
          <Route path="/howitworks" element={<Howitworks />} />
          <Route path="/upgrade" element={<Upgrade />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/community" element={<Community />} />
          <Route path="/sidebardata" element={<SideBarData />} />
          <Route path="/sidebar" element={<SideBar />} />
          <Route path="/studio" element={<Studio />} />
        </Routes>
      </BrowserRouter>
    </Fragment>
  );
}
export default App;
