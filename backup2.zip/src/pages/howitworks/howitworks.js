import React from 'react'

function Howitworks() {
    return (
        <div>
            <h1>Howitworks</h1>

        </div>
    )
}

export default Howitworks;
