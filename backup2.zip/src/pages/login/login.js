import Header from "../../components/header/header";
import React, { Fragment } from "react";
import { Container } from "react-bootstrap";
import LoginForm from "../../components/Forms/LoginForm";
import Footer from "../../components/footer/footer";
import './login.css'

const SignUp = () => {
  return (
    <Fragment>
      <div className='login'>
        {/* <Header  /> */}
        <div style={{ marginTop: 70 , paddingBottom: 35}}>
          <Container>
            <LoginForm />
          </Container>
        </div>
      </div>
      <Footer />
    </Fragment>
  );
};
export default SignUp;
