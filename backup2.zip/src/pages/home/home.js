import { Fragment } from "react";
import Header from "../../components/header/header";
import GoogelSignup from "../../components/home/googlesignup";
import Footer from "../../components/footer/footer";
// import Input_Signup from "../../components/home/input-signup";
import Text_Animation from "../../components/home/text";
import "./home.css";
import { useNavigate, Navigate } from "react-router-dom";
import { isLoggedIn } from '../../services/helpers';
import SideBarData from "../../components/sidebar/sidebardata";
export default function Home() {
  const navigate = useNavigate();


  return isLoggedIn() ? (
    <div>
      <Navigate to="/mainpage" />
    </div>

  ) : (
    <Fragment>
      <section className="containerhome">
        {/* <section className="headerhome">
          <Header buttonText="Sign in" buttonPath="/login" />
        </section> */}
        <section className="text-signup">
          <Text_Animation />
          {/* <Input_Signup /> */}
          <GoogelSignup />
        </section>
        <section className="Gif-video"></section>
      </section>
      <Footer />

    </Fragment>
  );
}
