import Header from "../../components/header/header";
import React, { Fragment } from "react";
import { Container } from "react-bootstrap";
import classes from "./studio.module.css";
import Footer from "../../components/footer/footer";
import PlanifyDraw from '../../components/studio/planify-pixi';

const Studio = () => {
  return (
    <Fragment>
      <div className={classes.studio}>
        <div style={{ marginTop: 0 , paddingBottom: 0}}>
          <PlanifyDraw/>
        </div>
      </div>
    </Fragment>
  );
};
export default Studio;
