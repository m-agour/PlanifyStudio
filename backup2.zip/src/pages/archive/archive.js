import React from 'react'
import { Link } from 'react-router-dom';

function Archive() {
  return (
    <div>
      <h1>Archive</h1>
    </div>
  )
}

export default Archive;
