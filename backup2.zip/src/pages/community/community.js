import React from 'react'

function Community() {
  return (
    <div>
            <h1>Community</h1>

    </div>
  )
}

export default Community;
