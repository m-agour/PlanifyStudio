import React, { Fragment } from "react";
// import Header from "../../components/header/header";
// import Footer from "../../components/footer/footer";
import { logOut, isLoggedIn } from '../../services/helpers';
import { useNavigate, Navigate } from "react-router-dom";
// import SideBar from "../../components/sidebar/sidebar";
import classes from './mainpage.css';
import { Card } from 'react-bootstrap';
// import Settings from "../settings/settings";



const MainPage = () => {
    const navigate = useNavigate();



    return !isLoggedIn() ? (
        <Navigate to="/login" />

    ) : (

        <Fragment>

            <div className={classes.mainpage}>
                {/* <h1>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h1>
                <h2>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h2>
                <h3>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h3>
                <h4>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h4>
                <h5>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h5>
                <h6>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h6>
                <h7>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h7> */}



            </div>

            <Card >
                {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                <Card.Body>
                    
                    <Card.Text>

                        <p>my last projects </p>
                <h2>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h2>
                <h3>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h3>
                <h4>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h4>
                <h5>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h5>
                <h6>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h6>
                <h7>main pageeeeeeeeeeeeeeeeeeeeeeeeeeeeee</h7> 


                    </Card.Text>
                    {/* <Button onClick={() => setEditMode(!editMode)} variant="primary">{editMode ? 'Save' : 'Edit'}</Button> */}
                </Card.Body>
            </Card>

        </Fragment >
    );
}
export default MainPage;
