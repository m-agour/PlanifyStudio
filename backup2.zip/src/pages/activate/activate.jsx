import Header from "../../components/header/header";
import React, { Fragment } from "react";
import Footer from "../../components/footer/footer";
import { logOut, isLoggedIn } from '../../services/helpers';
import { useNavigate, Navigate } from "react-router-dom";

const MainPage = () => {
  const navigate = useNavigate();

  const logout = ()=>{
    logOut()
    navigate("/")
  }
  return !isLoggedIn()?(
    <Navigate to="/login" />
  ):
  (
    <Fragment>
      <Header />
      <button onClick={logout}><p>Logout</p></button>
      <Footer />
    </Fragment>
  );
};
export default MainPage;
