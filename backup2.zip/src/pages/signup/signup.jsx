import Header from "../../components/header/header";
import React, { Fragment } from "react";
import { Container } from "react-bootstrap";
import SignupForm from "../../components/Forms/SignupForm";
import classes from "./signup.module.css";
import Footer from "../../components/footer/footer";

const SignUp = () => {
  return (
    <Fragment>
      <div className={classes.signup}>
        {/* <Header buttonText="Log in" buttonPath="/login" /> */}
        <div style={{ marginTop: 70 , paddingBottom: 35}}>
          <Container>
            <SignupForm />
          </Container>
        </div>
      </div>
      <Footer/>
    </Fragment>
  );
};
export default SignUp;
