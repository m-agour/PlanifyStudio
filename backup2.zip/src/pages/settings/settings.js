
import React, { useState } from 'react';
import classes from "./settings.css";
import { Button } from 'react-bootstrap';
import { Card } from 'react-bootstrap';



const Settings = () => {
    const [image, setImage] = useState(null);

    const handleImageChange = (event) => {
        setImage(URL.createObjectURL(event.target.files[0]));
    };

    const [profile, setProfile] = useState({
        name: 'John Doe',
        location: 'Los Angeles, CA',
        occupation: 'Web Developer',
        // profilePicture: 'https://example.com/profile.jpg'

    });
    const [editMode, setEditMode] = useState(false);

    const handleInputChange = (event) => {
        setProfile({ ...profile, [event.target.name]: event.target.value });
    };

    return (
        <div className='prof'>
            {/* <img src={profile.profilePicture} alt={profile.name} /> */}


            <Card style={{ width: '18rem' }}>
                {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                <Card.Body>
                    <Card.Title>
                        <h1>{profile.name}</h1>
                    </Card.Title>

                    <Card.Text>
                        <h6>You can edit your name, email address, account password, and language.</h6>

                        <p>Location: {profile.location}</p>
                        <p>Occupation: {profile.occupation}</p>
                        {editMode ? (
                            <>
                                <input
                                    type="text"
                                    name="name"
                                    value={profile.name}
                                    onChange={handleInputChange}
                                />
                                <input
                                    type="text"
                                    name="location"
                                    value={profile.location}
                                    onChange={handleInputChange}
                                />
                                <input
                                    type="text"
                                    name="occupation"
                                    value={profile.occupation}
                                    onChange={handleInputChange}
                                />
                            </>
                        ) : (
                            <>
                                <p>Location: {profile.location}</p>
                                <p>Occupation: {profile.occupation}</p>
                            </>
                        )}
                    </Card.Text>
                    <Button onClick={() => setEditMode(!editMode)} variant="primary">{editMode ? 'Save' : 'Edit'}</Button>
                </Card.Body>
            </Card>
        </div>
    );
};

export default Settings;
