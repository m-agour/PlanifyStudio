import React from 'react'

function Upgrade() {
    return (
        <div>
            <h1>upgrade</h1>

        </div>
    )
}

export default Upgrade
