import "bootstrap/dist/css/bootstrap.min.css";
import styles from "./forms.module.css";

import React from "react";
import { Fragment } from "react";
import Input from "./Input";
import { useEffect, useState, useRef } from "react";
import { FaGoogle } from "react-icons/fa";
import { signup } from "../../services/authServices";
import { useNavigate, Navigate } from "react-router-dom";
import {
  isLoggedIn,
  logOut,
  showSuccess,
  showError,
} from "../../services/helpers";

const SignupForm = (props) => {
  const [firstName, setFirstName] = useState(null);
  const [lastName, setLastName] = useState(null);
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);

  const navigate = useNavigate();

  const oSubmit = async (event) => {
    event.preventDefault();
  };

  const handleSubmit = async (event) => {
    if (!(email.valid && password.valid && firstName.valid && lastName.valid)) {
      showError("Please enter a correct data!");
      return;
    }
    // verify user
    const userData = {
      email: email.value,
      firstname: firstName.value,
      lastname: lastName.value,
      password: password.value,
      image_url: "/img/img1",
    };

    let res = await signup(userData);

    if (res) {
      showSuccess("Successfully singed up!");
      navigate("/app");
    } else {
      logOut();
    }
  };

  return isLoggedIn() ? (
    <Navigate to="/app" />
  ) : (
    <Fragment>
      <div className={styles.card}>
        <div className={styles.card_in}>
          <form
            className={styles["material-form"]}
            id="registration-form"
            method="POST"
            onSubmit={oSubmit}
            role="registration-form"
            noValidate="novalidate"
          >
            <div
              className={styles["promo-code-validation"]}
              style={{
                textAlign: "center",
                color: "#F22F46",
                marginBottom: "10px",
              }}
            ></div>
            <Input
              type="text"
              name="FirstName"
              label="First Name"
              valueSetter={setFirstName}
              tabIndex={1}
              required={true}
            />
            <Input
              type="text"
              name="LastName"
              label="Last Name"
              valueSetter={setLastName}
              tabIndex={2}
              required={true}
            />
            <Input
              type="email"
              name="Email"
              label="Email"
              valueSetter={setEmail}
              tabIndex={3}
              required={true}
            />
            <Input
              type="password"
              name="Password"
              label="Password (8+ Characters)"
              valueSetter={setPassword}
              tabIndex={4}
              required={true}
            />

            <div>
              <button
                id="signup-button"
                onClick={handleSubmit}
                type="submit"
                className={styles["m-button"]}
                data-loading-text="<i class='icon icon-spinner icon-spin'></i>"
                tabIndex={10}
              >
                Sign up
              </button>
              {/* <div style={{paddingTop: 20, textAlign: 'center'}}>
            <p className='or'>Or</p>
          </div> */}

              <button
                id="signup-button"
                type="submit"
                className={styles["m-button"] + " " + styles["google"]}
                data-loading-text="<i class='icon icon-spinner icon-spin'></i>"
                tabIndex={10}
              >
                <FaGoogle className={styles["google-icon"]} />
                &nbsp; | &nbsp; Sign up with Google
              </button>
            </div>
          </form>
        </div>
      </div>
    </Fragment>
  );
};
export default SignupForm;
