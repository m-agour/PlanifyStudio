import "bootstrap/dist/css/bootstrap.min.css";
import styles from "./forms.module.css";

import React from "react";
import { Fragment } from "react";
import Input from "./Input";
import { FaGoogle } from "react-icons/fa";
import { useEffect, useState, useRef } from "react";
import { login } from "../../services/authServices";
import { useNavigate, Navigate } from "react-router-dom";
import {
  isLoggedIn,
  logOut,
  showSuccess,
  showError,
} from "../../services/helpers";

const LoginForm = (props) => {
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);

  const navigate = useNavigate();

  //   useEffect(() =>{
  //     console.log(email, password);
  // }, [email, password])

  const handleSubmit = async (event) => {
    if (!(email.valid && password.valid)) {
      showError("Please enter a correct data!");
      return;
    }
    // verify user
    const userData = {
      email: email.value,
      password: password.value,
    };

    let res = await login(userData);

    if (res) {
      showSuccess("Successfully singed in!");
      navigate("/app");
    } else {
      logOut();
    }
  };
  
  const oSubmit = async (event) => {
    event.preventDefault();
  };

  return isLoggedIn() ? (
    <Navigate to="/app" />
  ) : (
    <Fragment>
      <br /> <br />
      <div className={styles.card}>
        <div className={styles.card_in}>
          <form
            className={styles["material-form"]}
            id="registration-form"
            method="POST"
            onSubmit={oSubmit}
            role="registration-form"
            noValidate="novalidate"
          >
            <div
              className={styles["promo-code-validation"]}
              style={{
                textAlign: "center",
                color: "#F22F46",
                marginBottom: "10px",
              }}
            ></div>
            <Input
              type="email"
              name="Email"
              label="Email"
              valueSetter={setEmail}
              tabIndex={3}
              required={true}
            />
            <Input
              type="password"
              name="Password"
              label="Password (8+ Characters)"
              valueSetter={setPassword}
              tabIndex={4}
              required={true}
            />

            <div className="buttons">
              <button
                id="signup-button"
                onClick={handleSubmit}
                type="submit"
                className={styles["m-button"] + " " + styles["google"]}
                data-loading-text="<i class='icon icon-spinner icon-spin'></i>"
                tabIndex={10}
              >
                Sign in
              </button>
              {/* <div style={{paddingTop: 20, textAlign: 'center'}}>
            <p className='or'>Or</p>
          </div> */}
              <button
                id="signup-button"
                type="submit"
                className={styles["m-button"]}
                data-loading-text="<i class='icon icon-spinner icon-spin'></i>"
                tabIndex={10}
              >
                <FaGoogle className={styles["google-icon"]} />
                &nbsp; | &nbsp; Sign in with Google
              </button>
            </div>
            <input
              type="hidden"
              name="partner"
              defaultValue={0}
              className={styles["sl_whiteout"]}
            />
            <input
              type="hidden"
              id="preferredLanguage"
              name="preferredLanguage"
              className={styles["sl_whiteout"]}
              defaultValue="en"
            />
          </form>
        </div>
      </div>
    </Fragment>
  );
};
export default LoginForm;
