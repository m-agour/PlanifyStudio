import React from "react";
import { useEffect, useState, useRef } from "react";
import styles from'./forms.module.css'

import validator from "validator";

const Input = (props) => {
  const [value, setValue] = useState("");
  const [hadValue, setHadValue] = useState(false);
  const [focused, setFocused] = useState(false);

  const inputRef = useRef();

  const updateField = () => {
    if (inputRef.current && inputRef.current.value.length > 0) {
      setHadValue(true);
      setValue(inputRef.current.value);
    }
  };

  useEffect(() => {
    updateField();
    props.valueSetter({value: value, valid: !notValid()})
  }, [value]);

  setInterval(updateField, 100);

  const onChange = (e) => {
    setValue(e.target.value);
  };

  const notValid = () => {
    let type = props.type;
    if (props.required && !value.length) return "Required";
    if (type === "text") {
      if (!validator.isAlpha(value))
        return "First name must only contain alphabetic characters";
    } else if (type === "password") {
      if (value.length < 8) return "Password is too short";
    } else if (type === "email") {
      if (!validator.isEmail(value)) return "Email is not valid";
    }
    return false;
  };

  const onFocus = () => {
    setFocused(true);
  };
  const onBlur = () => {
    setFocused(false);
  };

  return (
    <div
      className={
        styles["material-form-group"] + ' ' +
        (!value.length ? styles["pristine"] : " ") + ' ' +
        (hadValue && notValid() && !focused ? styles["has-error"] : "") + ' ' +
        (focused ? styles["focus"] : "")
      }
    >
      <label htmlFor={props.name}>
        {props.label} {props.required && "*"}
      </label>
      <input
        ref={inputRef}
        onChange={onChange}
        type={props.type}
        id={props.name}
        name={props.name}
        className={`${styles['material-form-control'] + ' ' + styles['l_whiteout']}`}
        tabIndex={props.tabIndex}
        maxLength={255}
        onFocus={onFocus}
        onBlur={onBlur}
      />
      <span htmlFor={props.name} className={styles["help-block"]  + ' ' + styles["m-b-0"]}>
        {notValid()}
      </span>
    </div>
  );
};

export default Input;
