import * as AiIcon from "react-icons/ai";
import * as CiIcon from "react-icons/ci";
import * as BiIcon from "react-icons/bi";
import * as RxIcon from "react-icons/rx";
import * as BsIcon from "react-icons/bs";
import classes from "./sidebar.css";

const SideBar = [

    {
        title: 'Home',
        path: '/mainpage',
        icon: <AiIcon.AiOutlineHome style={{ position: 'relative', top: '5px' }}/>,
        cName: 'nav-text'
    },
    {
        title: 'Projects',
        path: '/Settings',
        icon: <AiIcon.AiOutlineFundProjectionScreen style={{ position: 'relative', top: '5px' }} />,
        cName: 'nav-text'
    },

    {
        title: 'Trash',
        path: '/archive',
        icon: <AiIcon.AiOutlineDelete style={{ position: 'relative', top: '5px' }}/>,
        cName: 'nav-text'
    },
    {
        title: 'starred',
        path: '/community',
        icon: <AiIcon.AiOutlineStar style={{ position: 'relative', top: '5px' }} />,
        cName: 'nav-text'
    },
    // {
    //     title: 'How it works',
    //     path: '#/howitworks',
    //     icon: <BiIcon.BiShowAlt />,
    //     cName: 'nav-text'
    // },
    {
        title: 'Recent Projects',
        path: '/upgrade',
        icon: <AiIcon.AiOutlineClockCircle style={{ position: 'relative', top: '5px' }} />,
        cName: 'nav-text'
    },
    // {
    //     title: 'Projects',
    //     path: '#/Settings',
    //     icon: <AiIcon.AiOutlineSetting />,
    //     cName: 'nav-text'
    // },
    // {
    //     title: 'About Us',
    //     path: '/Footer',
    //     icon: <BsIcon.BsPen />,
    //     cName: 'nav-text'
    // },
]
export default SideBar;