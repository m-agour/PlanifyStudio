import React from 'react';
import { Fragment } from 'react';
import { Link } from 'react-router-dom';
import SideBar from './sidebar.js';
// 
import { NavLink } from 'react-bootstrap';
// import { GiCrackedGlass } from 'react-icons/gi';
import classes from "./sidebar.css";
import { logOut, isLoggedIn } from '../../services/helpers';
import { useNavigate, Navigate } from "react-router-dom";
// import { Button } from 'react-bootstrap';


const SideBarData = () => {
    const navigate = useNavigate();

    return !isLoggedIn() ? (
        <Navigate to="/" />

    ) : (
        <Fragment>


            <button className={'button'}>new</button>
            <ul className={'side'}>
                <NavLink to={"/"}>
                    <div className={'header_logo'}> Planify</div>
                </NavLink>


                {SideBar.map((item, index) => {
                    return (



                        <li key={index} className={item.cName}>
                            <Link to={item.path}>
                                {item.icon}
                                <span className={'titlle'}>{item.title}</span>
                            </Link>
                        </li>

                    );
                })}

            </ul>


        </Fragment>
    )
}

export default SideBarData;
