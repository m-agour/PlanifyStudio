// import { Fragment, useState } from "react";
// import "./input-signup.css";

// export default function Input_Signup() {
//   const [Email, setEmail] = useState("");
//   const handleEmailChange = (event) => {
//     setEmail(event.target.value);
//     console.log("", event.target.value);
//   };
//   const handleEmailClick = () => {
//     console.log("valu is:", Email);
//   };
//   const [Password, setPassword] = useState("");
//   const handlePassChange = (event) => {
//     setPassword(event.target.value);
//     console.log("", event.target.value);
//   };
//   const handlePassClick = () => {
//     console.log("valu is:", Password);
//   };
//   const [isclick, setisclick] = useState(false);
//   const handleisclick = () => {
//     if (!isValidEmail(Email)) {
//       setError("Email is invalid");
//     } else {
//       handleEmailClick();
//       setisclick(true);
//     }
//   };

//   function isValidEmail(email) {
//     return /\S+@\S+\.\S+/.test(email);
//   }
//   const [error, setError] = useState(null);

//   return (
//     <>
//       <section className="inputcontainer">
//         {isclick ? (
//           <>
//             <input
//               className="inputfield"
//               type="password"
//               id="password"
//               name="password"
//               fontSize="13px"
//               placeholder="password"
//               onChange={handlePassChange}
//               value={Password}
//             />
//             <button
//               className="button-79"
//               onClick={() => {
//                 handlePassClick();
//               }}
//             >
//               Signin
//             </button>
//           </>
//         ) : (
//           <>
//             <input
//               className="inputfield"
//               id="typeEmail"
//               name="message"
//               fontSize="13px"
//               placeholder="Email"
//               onChange={handleEmailChange}
//               value={Email}
//             />
//             <span
//               style={{
//                 fontWeight: "bold",
//                 color: "white",
//               }}
//             >
//               {error}
//             </span>
//             <button
//               className="button-79"
//               onClick={() => {
//                 handleisclick();
//               }}
//             >
//               Next
//             </button>
//           </>
//         )}
//       </section>
//     </>
//   );
// }
