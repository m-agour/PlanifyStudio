import { NavLink } from "react-router-dom";
import "./googlesignup.css";
export default function GoogelSignup() {
  return (
    <>
      <NavLink to={"./mainpage"} className="signup-button">
        <a className="textsignup">
          {" Let's start "}
          <span></span>
        </a>
      </NavLink>
    </>
  );
}
