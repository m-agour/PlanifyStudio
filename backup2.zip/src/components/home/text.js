import "./text.css";
export default function Text_Animation() {
  return (
    <h1 className="containerText">
      Let's create floor plans,
      <span className="spantextcontainer positio" style={{ height: "3.5em" }}>
        <span
          className="animy left-0 home-tagline-appendix"
          style={{ animationDelay: "0ms" }}
        >
          Accurately.
        </span>
        <span
          className="animy left-0 home-tagline-appendix"
          style={{ animationDelay: "1500ms" }}
        >
          instantly.
        </span>
        <span
          className="animy left-0 home-tagline-appendix"
          style={{ animationDelay: "3000ms" }}
        >
          automatically.
        </span>
        <span
          className="animy left-0 home-tagline-appendix"
          style={{ animationDelay: "4500ms" }}
        >
          securely.
        </span>
        <span
          className="animy left-0  home-tagline-appendix"
          style={{ animationDelay: "6000ms" }}
        >
          magically.
        </span>
        <span
          className="animy left-0 home-tagline-appendix"
          style={{ animationDelay: "7500ms" }}
        >
          collaboratively.
        </span>
        <span
          className="animy left-0 home-tagline-appendix"
          style={{ animationDelay: "9000ms" }}
        >
          together.
        </span>
      </span>
    </h1>
  );
}
