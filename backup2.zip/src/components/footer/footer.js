import React from "react";
import styles from './footer.module.css'

const Footer = (props) => {
  return (
    <footer
      className={styles["mainfooter"] + ' text-white text-center '} 
      style={{ backgroundColor: "#222022" }}
    >

      <div className={styles['footer_text'] + " text-center text-light"}>
        © 2023 Copyright:&nbsp;
        <a className="text-light" href="https://Planify.world/">
          Planify.world
        </a>
      </div>
    </footer>
  );
};

export default Footer;
